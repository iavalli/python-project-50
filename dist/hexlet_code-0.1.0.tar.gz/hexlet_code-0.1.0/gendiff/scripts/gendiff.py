import argparse

def main():
    parser = argparse.ArgumentParser()
    parser.parse_args()


if __name__ == '__main__':
    main()
